# Security Policy

## Supported Versions

Latest released version.

## Reporting a Vulnerability

Send an email to petri@digip.org.
